const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const carImg = new Image();
carImg.src = 'assets/buaya_mobil.png';

let car = {
  x: 200,
  y: 500,
  width: 100,
  height: 100,
  speed: 5
};

let obstacles = [];
const obstacleWidth = 80;
const obstacleHeight = 100;
let obstacleSpeed = 4;
let spawnTimer = 0;

let score = 0;

let keys = {};
document.addEventListener('keydown', (e) => keys[e.key] = true);
document.addEventListener('keyup', (e) => keys[e.key] = false);

function update() {
  if (keys['ArrowLeft']) car.x -= car.speed;
  if (keys['ArrowRight']) car.x += car.speed;
  car.x = Math.max(0, Math.min(canvas.width - car.width, car.x));

  spawnTimer++;
  if (spawnTimer > 60) {
    spawnTimer = 0;
    const x = Math.random() * (canvas.width - obstacleWidth);
    obstacles.push({ x, y: -obstacleHeight });
  }

  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].y += obstacleSpeed;

    if (
      car.x < obstacles[i].x + obstacleWidth &&
      car.x + car.width > obstacles[i].x &&
      car.y < obstacles[i].y + obstacleHeight &&
      car.y + car.height > obstacles[i].y
    ) {
      alert('GAME OVER! Skor: ' + score);
      window.location.reload();
    }

    if (obstacles[i].y > canvas.height) {
      obstacles.splice(i, 1);
      score++;
    }
  }
}

function draw() {
  ctx.fillStyle = '#444';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(carImg, car.x, car.y, car.width, car.height);

  ctx.fillStyle = 'red';
  for (let obs of obstacles) {
    ctx.fillRect(obs.x, obs.y, obstacleWidth, obstacleHeight);
  }

  ctx.fillStyle = 'white';
  ctx.font = '24px Arial';
  ctx.fillText('Skor: ' + score, 10, 30);
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

carImg.onload = () => {
  gameLoop();
};
